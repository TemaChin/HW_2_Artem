//
//  MyFriendViewController.swift
//  HomeWork_2_AppScreens
//
//  Created by Артем Станкевич on 19.10.2020.
//

import UIKit

class MyFriendViewController: UIViewController {
    
    var currentFriend: MyFriendProfile? = nil
    var myFriendsNameLabel: UILabel?
    var myFriendsCityLabel: UILabel?
    var myFriendsBackButton: UIButton?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        myFriendsNameLabel = MyLabel(frame: CGRect(x: self.view.bounds.minX, y: self.view.bounds.midY/4, width: self.view.bounds.width/2, height: 50))
        myFriendsNameLabel!.text = currentFriend?.name
//        myFriendsNameLabel!.font = setText("Helvetica", 20)
        myFriendsNameLabel!.textColor = setTextColorBlue()
        self.view.addSubview(myFriendsNameLabel!)

        myFriendsCityLabel = MyLabel(frame: CGRect(x: self.view.bounds.minX, y: self.view.bounds.midY/3, width: self.view.bounds.width/2, height: 50))
        myFriendsCityLabel!.text = currentFriend?.info
//        myFriendsCityLabel!.font = setText("Helvetica", 20)
        myFriendsCityLabel!.textColor = setTextColorBlue()
        self.view.addSubview(myFriendsCityLabel!)

        myFriendsBackButton = MyButton(frame: CGRect(x: self.view.bounds.minX, y: self.view.bounds.midY/10, width: 50, height: 50))
        myFriendsBackButton!.setTitle("back", for: .normal)
        myFriendsBackButton!.setTitleColor(.black, for: .normal)
        myFriendsBackButton!.layer.cornerRadius = 5.0
        myFriendsBackButton!.layer.borderColor = UIColor.black.cgColor
        myFriendsBackButton!.layer.borderWidth = 1.0
        myFriendsBackButton!.clipsToBounds = true
        self.view.addSubview(myFriendsBackButton!)
        myFriendsBackButton!.addTarget(self, action: #selector(myFriendBackButtonAction), for: .touchUpInside)
        
        
    }
    
    @ objc func myFriendBackButtonAction() {
        let viewController = UIStoryboard(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "NaviFriendsViewController")
        UIApplication.shared.keyWindow?.rootViewController = viewController
    }

}

extension MyFriendViewController: IInputView {
    func input(_ data: Any?) {
        if let data = data as? MyFriendProfile {
            self.currentFriend = data
        }
    }
}

extension MyFriendViewController {
    
    func setText(_ name: String, _ sizeFont: Int) -> UIFont {
        return UIFont(name: name, size: CGFloat(sizeFont))!
    }
    
    func setTextColorBlue()->UIColor {
        return UIColor.blue
    }
}
