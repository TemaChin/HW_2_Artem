//
//  MyViewController.swift
//  HomeWork_2_AppScreens
//
//  Created by Артем Станкевич on 20.10.2020.
//

import UIKit

class MyViewController: UIViewController {

    var myNameLabel: MyLabel?
    var myCityLabel: MyLabel?
    var myFriends: MyButton?
    var nameMain = "Василий"
    var cityMain = "СПб"

    
    override func loadView() {
        super.loadView()
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myNameLabel = MyLabel(frame: CGRect(x: self.view.bounds.minX, y: self.view.bounds.midY/4, width: self.view.bounds.width/2, height: 50))
        myNameLabel!.text = nameMain
//        myNameLabel!.font = setText("Helvetica", 20)
        myNameLabel!.textColor = setTextColorBlue()
        self.view.addSubview(myNameLabel!)
        
        myCityLabel = MyLabel(frame: CGRect(x: self.view.bounds.minX, y: self.view.bounds.midY/3, width: self.view.bounds.width/2, height: 50))
        myCityLabel!.text = cityMain
        myCityLabel!.font = setText("Helvetica", 10)
        myCityLabel!.textColor = setTextColorBlue()
        self.view.addSubview(myCityLabel!)
        
        myFriends = MyButton(frame: CGRect(x: self.view.bounds.minX+50, y: self.view.bounds.midY/2, width: 70, height: 50))
        myFriends!.setTitle("Friends", for: .normal)
        myFriends!.backgroundColor = .blue
        myFriends!.layer.borderColor = UIColor.black.cgColor
        myFriends!.layer.borderWidth = 1.0
        myFriends!.layer.cornerRadius = 5.0
        myFriends!.clipsToBounds = true
        self.view.addSubview(myFriends!)
        myFriends!.addTarget(self, action: #selector(vkFriendsButtonAction), for: .touchUpInside)
        
    }
    
    @ objc func vkFriendsButtonAction() {
        let viewController = UIStoryboard(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "NaviFriendsViewController")
        UIApplication.shared.keyWindow?.rootViewController = viewController
    }
    
    
}

extension MyViewController {
    
    func setText(_ name: String, _ sizeFont: Int) -> UIFont {
        return UIFont(name: name, size: CGFloat(sizeFont))!
    }
    
    func setTextColorBlue()->UIColor {
        return UIColor.blue
        }

}


