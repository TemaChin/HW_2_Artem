//
//  FriendsViewController.swift
//  HomeWork_2_AppScreens
//
//  Created by Артем Станкевич on 19.10.2020.
//

import UIKit



class FriendsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var dataModel = DataFriendProfile.myFriendData
    var addFriendButton: MyButton?
    
    @IBOutlet weak var friendsTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let cell = UINib(nibName: "FriendsCell", bundle: nil)
        self.friendsTableView.register(cell, forCellReuseIdentifier: "cell")
        
        let model = MyFriendProfile("Vitek", "Voronesh")
        
        dataModel.append(model)
        
        addFriendButton = MyButton(frame: CGRect(x: self.view.bounds.maxX-100, y: self.view.bounds.midY/10, width: 50, height: 50))
        addFriendButton!.setTitle("Add", for: .normal)
        addFriendButton?.setTitleColor(.black, for: .normal)
        addFriendButton!.layer.borderColor = UIColor.black.cgColor
        addFriendButton!.layer.borderWidth = 1.0
        addFriendButton!.layer.cornerRadius = 5.0
        addFriendButton!.clipsToBounds = true
        self.view.addSubview(addFriendButton!)
        addFriendButton!.addTarget(self, action: #selector(addFriendButtonAction), for: .touchUpInside)

    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return dataModel.count
        }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 100
        }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! FriendsCell
        
            cell.friendsNameLabel?.text = dataModel[indexPath.row].name
            cell.friendsDetailLabel?.text = dataModel[indexPath.row].info

            return cell
        }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let item = dataModel[indexPath.row]
        let viewController = UIStoryboard(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "MyFriendViewController") as! MyFriendViewController
        viewController.input(item)
        UIApplication.shared.keyWindow?.rootViewController = viewController
    }
    
    @ objc func addFriendButtonAction() {
        if let viewController = String(describing: AddFriendViewController.self).viewController() as? AddFriendViewController {
            self.navigationController?.pushViewController(viewController, animated: true)
            viewController.listener = self
        }

        }
    
    }


extension String {
    func changeVC(_ storyboard: String = "Main")->UIViewController? {
        let storyboard = UIStoryboard(name: storyboard, bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: self)
        return vc
    }
}

extension FriendsViewController: OutputView {
    func output(_ data: Any?, identifier: String) {
        if identifier == String(describing: AddFriendViewController.self) {
            if let data = data as? MyFriendProfile {
                self.dataModel.append(data)
                self.friendsTableView.reloadData()
            }
        }
    }
}
