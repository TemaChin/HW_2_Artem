//
//  AddFriendViewController.swift
//  HomeWork_2_AppScreens
//
//  Created by Артем Станкевич on 24.10.2020.
//

import UIKit

class AddFriendViewController: UIViewController {
    
    var nameFriendAddFriendLabel: MyLabel?
    var cityFriendAddFriendLabel: MyLabel?
    var nameFriendAddFriendTextField: MyTextField?
    var cityFriendAddFriendTextField: MyTextField?
    var addBackButton: MyButton?
    var addDoneButton: MyButton?
    var createdFrind: MyFriendProfile? = nil
    weak var listener: OutputView? = nil
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        nameFriendAddFriendLabel = MyLabel(frame: CGRect(x: (self.view.bounds.midX)-(self.view.bounds.width-50)/2, y: self.view.bounds.midY/4, width: self.view.bounds.width-50, height: 50))
        nameFriendAddFriendLabel!.text = "Имя друга"
 //       nameFriendAddFriendLabel!.font = setText("Helvetica", 20)
        self.view.addSubview(nameFriendAddFriendLabel!)
        
        nameFriendAddFriendTextField = MyTextField(frame: CGRect(x: (self.view.bounds.midX)-(self.view.bounds.width-50)/2, y: self.view.bounds.midY/4+nameFriendAddFriendLabel!.bounds.height, width: self.view.bounds.width-50, height: 50))
        nameFriendAddFriendTextField!.font = setText("Helvetica", 15)
        nameFriendAddFriendTextField!.layer.cornerRadius = 5.0
        nameFriendAddFriendTextField!.layer.borderColor = UIColor.black.cgColor
        nameFriendAddFriendTextField!.layer.borderWidth = 1.0
        self.view.addSubview(nameFriendAddFriendTextField!)
        
        cityFriendAddFriendLabel = MyLabel(frame: CGRect(x: (self.view.bounds.midX)-(self.view.bounds.width-50)/2, y: self.view.bounds.midY/4+nameFriendAddFriendLabel!.bounds.height*2, width: self.view.bounds.width-50, height: 50))
        cityFriendAddFriendLabel!.text = "Город друга"
        cityFriendAddFriendLabel!.font = setText("Helvetica", 20)
        self.view.addSubview(cityFriendAddFriendLabel!)
        
        cityFriendAddFriendTextField = MyTextField(frame: CGRect(x: (self.view.bounds.midX)-(self.view.bounds.width-50)/2, y: self.view.bounds.midY/4+nameFriendAddFriendLabel!.bounds.height*3, width: self.view.bounds.width-50, height: 50))
        cityFriendAddFriendTextField!.font = setText("Helvetica", 15)
        cityFriendAddFriendTextField!.layer.cornerRadius = 5.0
        cityFriendAddFriendTextField!.layer.borderColor = UIColor.black.cgColor
        cityFriendAddFriendTextField!.layer.borderWidth = 1.0
        self.view.addSubview(cityFriendAddFriendTextField!)
        
        addBackButton = MyButton(frame: CGRect(x: self.view.bounds.minX+50, y: self.view.bounds.midY/10, width: 50, height: 50))
        addBackButton!.setTitle("back", for: .normal)
        addBackButton!.setTitleColor(.black, for: .normal)
        addBackButton!.layer.cornerRadius = 5.0
        addBackButton!.layer.borderColor = UIColor.black.cgColor
        addBackButton!.layer.borderWidth = 1.0
        addBackButton!.clipsToBounds = true
        self.view.addSubview(addBackButton!)
        addBackButton!.addTarget(self, action: #selector(addFriendBackButtonAction), for: .touchUpInside)
        
        addDoneButton = MyButton(frame: CGRect(x: self.view.bounds.maxX-100, y: self.view.bounds.midY/10, width: 50, height: 50))
        addDoneButton!.setTitle("add", for: .normal)
        addDoneButton!.setTitleColor(.black, for: .normal)
        addDoneButton!.layer.cornerRadius = 5.0
        addDoneButton!.layer.borderColor = UIColor.black.cgColor
        addDoneButton!.layer.borderWidth = 1.0
        addDoneButton!.clipsToBounds = true
        self.view.addSubview(addDoneButton!)
        addDoneButton!.addTarget(self, action: #selector(addFriendDoneButtonAction), for: .touchUpInside)
    
    }
    
    
    @ objc func addFriendBackButtonAction() {
        let viewController = UIStoryboard(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "NaviFriendsViewController")
        UIApplication.shared.keyWindow?.rootViewController = viewController
    }

    @ objc func addFriendDoneButtonAction() {
        
        let name = nameFriendAddFriendTextField?.text ?? "не указано имя"
        let city = cityFriendAddFriendTextField?.text ?? "не указан город"
        let newFriend = MyFriendProfile(name, city)
        self.listener?.output(newFriend, identifier: String(describing: AddFriendViewController.self))
        self.navigationController?.popViewController(animated: true)

    }
    
}

extension AddFriendViewController: UITextFieldDelegate {
    
    func setText(_ name: String, _ sizeFont: Int) -> UIFont {
        return UIFont(name: name, size: CGFloat(sizeFont))!
    }
    
    func setTextColorBlue()->UIColor {
        return UIColor.blue
        }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        resignFirstResponder()
        return true
    }
}
