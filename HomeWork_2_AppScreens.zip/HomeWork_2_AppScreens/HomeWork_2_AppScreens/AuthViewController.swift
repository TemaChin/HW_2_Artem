//
//  AuthScreen.swift
//  HomeWork_2_AppScreens
//
//  Created by Артем Станкевич on 18.10.2020.
//

import UIKit

class AuthViewController: UIViewController {
    
    var vkLabel: MyLabel?
    var vkTextLogin: MyTextField?
    var vkTextPassword: MyTextField?
    var vkLoginLabel: MyLabel?
    var vkPasswordLabel: MyLabel?
    var vkAuthButton: MyButton?
    
    override func loadView() {
        super.loadView()
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        vkLabel = MyLabel(frame: CGRect(x: (self.view.bounds.midX)-(self.view.bounds.width)/2, y: (self.view.bounds.midY)/2-100/2, width: self.view.bounds.width, height: 100))
        vkLabel!.text = "Vkontakte"
 //       vkLabel!.font = setText("Helvetica", 20)
        vkLabel!.textColor = setTextColorBlue()
        self.view.addSubview(vkLabel!)
        
        vkTextLogin = MyTextField(frame: CGRect(x: (self.view.bounds.midX)-(self.view.bounds.width-50)/2, y: self.view.bounds.midY-(self.view.bounds.midY/5), width: self.view.bounds.width-50, height: 50))
        vkTextLogin!.font = setText("Helvetica", 15)
        vkTextLogin!.layer.cornerRadius = 5.0
        vkTextLogin!.layer.borderColor = UIColor.black.cgColor
        vkTextLogin!.layer.borderWidth = 1.0
        self.view.addSubview(vkTextLogin!)
        
        vkLoginLabel = MyLabel(frame: CGRect(x: (self.view.bounds.midX)-(self.view.bounds.width-50)/2, y: self.view.bounds.midY/2+50, width: self.view.bounds.width-50, height: 50))
        vkLoginLabel!.text = "login"
        vkLoginLabel!.font = setText("Helvetica", 15)
        self.view.addSubview(vkLoginLabel!)
        
        vkTextPassword = MyTextField(frame: CGRect(x: (self.view.bounds.midX)-(self.view.bounds.width-50)/2, y: self.view.bounds.midY+(self.view.bounds.midY/5), width: self.view.bounds.width-50, height: 50))
        vkTextPassword!.font = setText("Helvetica", 15)
        vkTextPassword!.layer.cornerRadius = 5.0
        vkTextPassword!.layer.borderColor = UIColor.black.cgColor
        vkTextPassword!.layer.borderWidth = 1.0
        self.view.addSubview(vkTextPassword!)
        
        vkPasswordLabel = MyLabel(frame: CGRect(x: (self.view.bounds.midX)-(self.view.bounds.width-50)/2, y: self.view.bounds.midY/2+180, width: self.view.bounds.width-50, height: 50))
        vkPasswordLabel!.text = "password"
        vkPasswordLabel!.font = setText("Helvetica", 15)
        self.view.addSubview(vkPasswordLabel!)
        
        vkAuthButton = MyButton(frame: CGRect(x: self.view.bounds.midX-50, y: self.view.bounds.midY+200, width: 100, height: 50))
        vkAuthButton!.setTitle("Sign UP", for: .normal)
        vkAuthButton!.backgroundColor = .blue
        vkAuthButton!.layer.borderColor = UIColor.black.cgColor
        vkAuthButton!.layer.borderWidth = 1.0
        vkAuthButton!.layer.cornerRadius = 5.0
        vkAuthButton!.clipsToBounds = true
        self.view.addSubview(vkAuthButton!)
        vkAuthButton!.addTarget(self, action: #selector(vkAuthButtonAction), for: .touchUpInside)
        
        }
        
    @objc func vkAuthButtonAction() {
        
        if let login = vkTextLogin!.text,
           let password = vkTextPassword!.text {
            if login == auth.login, password == auth.password {
                let viewController = UIStoryboard(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "MyViewController")
                UIApplication.shared.keyWindow?.rootViewController = viewController
            }
        }
    }
    
    
    /// Функция теста при правильном логине и пароле переходит ли на основной экран
    func testAuthVasja(_ name: String, _ password: String)-> String {
        vkTextLogin = MyTextField(frame: CGRect(x: (self.view.bounds.midX)-(self.view.bounds.width-50)/2, y: self.view.bounds.midY-(self.view.bounds.midY/5), width: self.view.bounds.width-50, height: 50))
        vkTextLogin!.text = "Vasja"
        vkTextPassword = MyTextField(frame: CGRect(x: (self.view.bounds.midX)-(self.view.bounds.width-50)/2, y: self.view.bounds.midY+(self.view.bounds.midY/5), width: self.view.bounds.width-50, height: 50))
        vkTextPassword!.text = "12345"
        vkAuthButtonAction()
        if self.storyboard?.instantiateInitialViewController() == storyboard?.instantiateViewController(withIdentifier: "MyViewController") {
            return "MyViewController"
        }
        return ""
    }
}

extension AuthViewController {
    
    func setText(_ name: String, _ sizeFont: Int) -> UIFont {
        return UIFont(name: name, size: CGFloat(sizeFont))!
    }
    
    func setTextColorBlue()->UIColor {
        return UIColor.blue
    }
}
