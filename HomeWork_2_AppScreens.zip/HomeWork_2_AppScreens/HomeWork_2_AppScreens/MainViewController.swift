//
//  MainViewController.swift
//  HomeWork_2_AppScreens
//
//  Created by Артем Станкевич on 18.10.2020.
//

import UIKit

class MainViewController: UIViewController {
    
    override func loadView() {
        super.loadView()
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    
    

}



