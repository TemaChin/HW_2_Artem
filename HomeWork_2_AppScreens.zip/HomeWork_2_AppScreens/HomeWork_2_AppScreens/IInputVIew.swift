//
//  IInputVIew.swift
//  HomeWork_2_AppScreens
//
//  Created by Артем Станкевич on 18.10.2020.
//

import Foundation
/// протокол выхода данных
protocol IInputView: class {
    func input(_ data: Any?)
}


